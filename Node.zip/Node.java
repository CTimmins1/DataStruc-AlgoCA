/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author CamaraAdmin
 */
public class Node {
    public String song;
    public String genre;
    public Node next;

    public Node(String song, String genre) {
        //these are the elements that the node itself hold.
        this.song = song;
        this.genre = genre;
        this.next = null;
    }
}

