
import java.util.Collections;
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author CamaraAdmin
 */
//import java.util.MyLinkedList
public class MyLinkedList {

    private java.util.LinkedList<String> songList;
    private java.util.LinkedList<String> genreList;
    private java.util.LinkedList<String> rapList;
    private java.util.LinkedList<String> popList;

    public MyLinkedList() {
        //for some reason i had to physcially import inline the list util. I tried to fix imports but it would not import it no matter what I tried.
        songList = new java.util.LinkedList<String>();
        genreList = new java.util.LinkedList<String>();
        rapList = new java.util.LinkedList<String>();
        popList = new java.util.LinkedList<String>();
    }

    public void addSong(String song, String genre) {
        if (songList.size() < 5 && genreList.size() < 5) {
            songList.add(song);
            genreList.add(genre);
        } else {
            JOptionPane.showMessageDialog(null, "Maximum Songs reached pal.");
        }
    }

    public void addPlaylist(String song, String genre) {
        if (genre.equals("pop")) {
            popList.clear();//this will clear the poplist to remove previous entries
            popList.add(song);
            JOptionPane.showMessageDialog(null,"Pop song has been added");
        } else if (genre.equals("rap")) {
            rapList.clear();
            rapList.add(song);
             JOptionPane.showMessageDialog(null,"Rap song has been added");

        } else {
            JOptionPane.showMessageDialog(null, "This is a rap and pop app only fam.");
        }
    }

    public void removeFirstSong() {
        if (!songList.isEmpty() && !genreList.isEmpty()) {
            songList.removeFirst();
            genreList.removeFirst();
        }
    }

    public void shuffleSongs() {
        //https://www.geeksforgeeks.org/collections-shuffle-method-in-java-with-examples/ got this great example of how to shuffle things using the shuffle() method. very easy to implement and I am trying to imitate the smart shuffle feature on spotify.
        Collections.shuffle(songList);

    }

    public void eraseAllSongs() {
        //clearing both my linked lists to ensure no remants that would cause an error.
        songList.clear();
        genreList.clear();
        
    }

    public String getListAsString() {
        //strinf builder builds strings(duh) but is a convenient way of building strings together. as seen  by both the string of " song" and "genre"
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < songList.size(); i++) {
            builder.append("Song: ").append(songList.get(i)).append(", Genre: ").append(genreList.get(i)).append("\n");
        }
        return builder.toString();
    }

    //Again I  have to specify the java.util.LinkedList to avoid any confusion in my program
    public java.util.LinkedList<String> getSongList() {
        return songList;
    }
    public java.util.LinkedList<String> getGenreList(){
        return genreList;
    }
    public java.util.LinkedList<String> getPopList(){
        return popList;
    }
    public java.util.LinkedList<String> getRapList(){
        return rapList;
}
}