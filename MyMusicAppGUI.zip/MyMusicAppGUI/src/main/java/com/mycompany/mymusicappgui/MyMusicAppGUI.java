/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mymusicappgui;

/**
 *
 * @author CamaraAdmin
 */
public class MyMusicAppGUI {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
